function [ Reconstructed_image ] =EMD_reconstruction(Noisy_blured,clean_image,filter,nvar,extension,symmetry_type,alpha)

wait_bar = waitbar(0, 'Please wait...');
waitbar(1/5, wait_bar);

y=double(Noisy_blured);
[M N]=size(y);
nsigma=sqrt(nvar);
%% parameter setting
E=mean(y(:));
mu=5e-4*E;

X_Reg=cell(M,N);
b=cell(M,N);
% figure;imshow(d);
nb = 4;%nb-no of subbands used
a=log(1+y);
X_Reg{1}=wiener2(a,[3,3]);
X_Reg{2}=wiener2(a,[5,5]);
X_Reg{3}=wiener2(a,[7,7]);
X_Reg{4}=wiener2(a,[9,9]);
[m n]=size(a);
for p=1:1
    recons=0;
    %% Decomposition using emd
    D=bemd(X_Reg{p});
    [m n s]=size(D);
    %%    %% Wavelet Thresholding
    
    % iit{1}=ii{1};t
    for i=1:s-3
            

          %%  threshold calculation 
         A=D(:,:,i);
        sigma = median(abs(A(:)))/0.6745;        
        t1=2*sigma
        k=i;
        B=thresh_low(A,t1,k); % actual thresholing operation
        recons=recons+B;
    end

   recons=recons+D(:,:,s-2)+D(:,:,s-1)+D(:,:,s);
    b{p}=exp(recons)-1;
end 
Aux = cat(4,b{1});
div_Aux= diff(Aux,2);
div_Aux = cat(1,div_Aux, zeros(1,256),zeros(1,256));
waitbar(4/5, wait_bar);
%
%% Establishment of linear system of equations Ax = b
g=exp(X_Reg{1})-1;
[F,A,b]=Linear_system_of_equations(Aux,div_Aux,g,alpha);
I = eye(size(A));
c = real(F'*clean_image(:)); 
x = pinv(A+mu*I)*c ;
Reconstructed_image = real(reshape(F*x,M,N));

waitbar(5/5, wait_bar);

close (wait_bar);

end

