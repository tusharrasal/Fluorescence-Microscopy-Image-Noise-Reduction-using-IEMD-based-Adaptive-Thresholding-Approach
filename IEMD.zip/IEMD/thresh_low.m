function [B] = thresh_low(A,t,k)

SORH='h';
switch k
    case 1                          %% for LOW APPRO subband LL
for i=1:size(A,1)
    for j=1:size(A,2)      
    if ((A(i,j))<= 0.7097 &&(abs(A(i,j))<=t))
            B(i,j) = 0;
        else
         B(i,j)=A(i,j);

         end
    end
end


case 2                          %% for Horizontal subband HL
for i=1:size(A,1)
    for j=1:size(A,2)
        
        if mod(j,2)==1   % keping odd column
             B(i,j)=A(i,j);
            
        elseif abs(A(i,j))<=t
            B(i,j) = 0; % apply threhold
        else
          B(i,j) = A(i,j);
      

            end
    end
end

case 3                   %%  for vertical subband LH
    
    for i=1:size(A,1)
    for j=1:size(A,2)
        
        if mod(i,2)==1
             B(i,j)=A(i,j);
            
        elseif abs(A(i,j))<=t
            B(i,j) = 0;
        else
         B(i,j) = A(i,j);

            end
    end
    end
      
 case 4                 %%  for Diagonal subband HH

         B=A;

      
  case 5                          %% for Horizontal subband HL
for i=1:size(A,1)
    for j=1:size(A,2)
        
        if mod(j,2)==1
             B(i,j)=wthresh(A(i,j),SORH,t);
            
        elseif abs(A(i,j))<=t
            B(i,j) = 0;
        else
         B(i,j) = A(i,j);
            end
    end
end

case 6                   %%  for vertical subband LH
    
    for i=1:size(A,1)
    for j=1:size(A,2)
        
        if mod(i,2)==1
             B(i,j)=wthresh(A(i,j),SORH,t);
            
        elseif abs(A(i,j))<=t
            B(i,j) = 0;
        else
         B(i,j) = A(i,j);

            end
    end
    end
      
 case 7                %%  for Diagonal subband HH
      
      for i=1:size(A,1)
    for j=1:size(A,2)
        
%         if mod(i,2)==1
%              B(i,j)=A(i,j);
            
        if abs(A(i,j))>=t
            B(i,j) = 0;
        else
   B(i,j) = A(i,j);

         end
    end
      end 
 
      
end
       
            
        

