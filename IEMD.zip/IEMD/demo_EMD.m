clear all;
clc;
close all;

%% experimental setting
 image_name='0062.jpg'; 
 clean_image=double(imread(image_name));
 clean_image=clean_image(197:452,307:562);

%% Convolution kernel
s=3;
filter_type={'gaussian' s};
% filter_type={'microscopy' s};

% Gaussian noise level
nvar=1;

% boundary condition periodic or symmetric
extension = 'periodic'; 
symmetry_type = 'NA'; % not available for periodic extension


% generate blured image 

% h is convoluton kernal
[blurred_image,filter]=Image_blurring(clean_image,filter_type,extension,symmetry_type);

 %% MATLAB script which adds shot noise (Poisson noise) and read noise (Gaussian noise) to an image.  

% ----- Pixel Well Depth ----- %
quantum_well_depth =100;%93; % in photoelectrons
% ---------------------------- %

% ----- Image ----- %
I = round(blurred_image*quantum_well_depth/2^8);
% I = round(blurred_image*(quantum_well_depth)/(2^8));
% ----------------- %

% ----- Shot Noise ----- %
% alp=input('enter the value of alpha')
alpha=1;

Noisy_blured = alpha*poissrnd(I/alpha);

% ----- Read Noise ----- %
sigma_read =nvar ; % photoelectrons RMS
 Noisy_blured = Noisy_blured+ sigma_read*randn(size(Noisy_blured));% randn--Normally distributed random number
 figure;imshow(Noisy_blured,[]);
title('Input Noisy blurred image');

%% PURE-LET DECONVOLUTION to------ RESTORED IMAGE
tic;
Reconstructed_image=EMD_reconstruction(Noisy_blured,clean_image,filter,nvar,extension,symmetry_type,alpha);
toc;
fprintf(['===============================/n']);
figure;imshow(Reconstructed_image,[]);
title('Reconstructed_image');

%% Show results
Reconstructed_image=double(Reconstructed_image);
PSNR1 = psnr(Noisy_blured,clean_image,max(max(clean_image)))
PSNR2 = psnr((Reconstructed_image),clean_image,max(max(clean_image)))
improvment_PSNR = PSNR2-PSNR1
X1=double(Reconstructed_image);
 X2=double(clean_image);
%% Structurally similarity index Measure
% 
 SSIM = ssim(X1,X2)
% % 
%% Correlation Parameter
%Quantitative measure for edge preservation while supressing noise..
  Correlation_para=corr2(X1,X2)
