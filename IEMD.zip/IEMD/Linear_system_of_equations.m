function [ F,A,b] = Linear_system_of_equations ( Aux,div_Aux,x_inv,alpha )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This section is to establish linear system of equations Ax=b
%%%%%%%%%%%%%%%%%% Establishing euation Ax=b%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% nb=3*3;
% t=size(div_Aux)
%% Periodic boundary conditions

    [M,N,K]=size(Aux);
    F=zeros(M*N,K);
    for i=1:K
        F(:,i)=reshape(Aux(:,:,i),M*N,1); % Aux reshape into M*N by 1 and stored into F
    end
    
       first_term = F'*x_inv(:); % equation no.8  Implementation here
%     
       [M,N,K]=size(div_Aux);
    F_div=zeros(M*N,K);
    for i=1:K
        F_div(:,i)=reshape(div_Aux(:,:,i),M*N,1); % Aux reshape into M*N by 1 and stored into F
    end
    


%   second_term =diag(omega)'* x_inv(:);
%    second_term = omega.*F_div'* x_inv(:);
%    second_term = diag(omega'*alpha).*F_div'* x_inv(:);
     second_term = alpha*F_div'*x_inv(:);
%      second_term = 0; 
  
    clear alpha omega; 

A = F'*F; b = (first_term-second_term);  
factor = 1/M*N;   A = factor*A;   b = factor*b; 


end

