function [c]=corr(a,b)
% This program for Correlation measure between original Image 'a' and
% denoised image 'b'.
% close all;
% clear all;
% clc;
% a=magic(16)
% b=magic(8);
a=double(a);
b=double(b);
ma=mean2(a);
mb=mean2(b);
num=0;
den=0;
den1=0;
den2=0;
for i=1:size(b,1)
    for j=1:size(b,2)
        num=num+((a(i,j)-ma)*(b(i,j)-mb));
        den1=den1+(a(i,j)-ma)^2;
        den2=den2+(b(i,j)-mb)^2;
    end
end
den=(den1)*(den2);
den=sqrt(den);
c=(num)/(den);
